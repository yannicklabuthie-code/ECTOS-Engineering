Set-StrictMode -Version 2.0
function Get-EctosQfByteIdentity {
    [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$Path)
    if(-not (Test-Path -LiteralPath $Path -PathType Leaf)){ throw 'QF_INPUT_FILE_NOT_FOUND' }
    $fi=Get-Item -LiteralPath $Path
    $sha=(Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToUpperInvariant()
    [pscustomobject]@{ Path=$fi.FullName; SizeBytes=[int64]$fi.Length; SHA256=$sha }
}
