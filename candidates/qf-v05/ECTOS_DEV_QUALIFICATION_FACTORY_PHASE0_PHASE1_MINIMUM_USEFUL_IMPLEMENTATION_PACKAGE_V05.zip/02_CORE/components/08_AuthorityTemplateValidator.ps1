Set-StrictMode -Version 2.0
function Test-EctosQfAuthorityTemplate {
 [CmdletBinding()] param([hashtable]$Authority)
 if($null -eq $Authority){return [pscustomobject]@{Status='FAIL';Reason='AUTHORITY_ABSENT'}}
 $required=@('AUTHORITY_ID','ACTIVE','CONSUMED','SCOPE')
 $missing=@($required | Where-Object { -not $Authority.ContainsKey($_) })
 if($missing.Count -gt 0){return [pscustomobject]@{Status='FAIL';Reason='AUTHORITY_FIELDS_MISSING';Missing=$missing}}
 if($Authority.ACTIVE -ne 'YES'){return [pscustomobject]@{Status='FAIL';Reason='AUTHORITY_INACTIVE'}}
 if($Authority.CONSUMED -eq 'YES'){return [pscustomobject]@{Status='FAIL';Reason='AUTHORITY_ALREADY_CONSUMED'}}
 [pscustomobject]@{Status='PASS';Reason='ACTIVE_UNCONSUMED_TEMPLATE'}
}
