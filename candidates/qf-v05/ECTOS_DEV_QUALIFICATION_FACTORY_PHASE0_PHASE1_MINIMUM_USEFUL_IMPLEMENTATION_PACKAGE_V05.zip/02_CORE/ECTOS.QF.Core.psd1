﻿@{
 RootModule='ECTOS.QF.Core.psm1'
 ModuleVersion='1.0.0'
 GUID='d931b548-4a61-4f62-b736-e1eef0810cf3'
 Author='ECTOS DEV - Qualification Factory'
 CompanyName='ECTOS'
 Copyright='ECTOS'
 PowerShellVersion='5.1'
 FunctionsToExport=@(
  'Assert-EctosQfNativeWindowsPowerShell51','Compare-EctosQfProtectedStateSnapshot','Get-EctosQfByteIdentity','Get-EctosQfFailureAttribution','Get-EctosQfProtectedStateSnapshot','Get-EctosQfRulesetAggregateSha256','Get-EctosQfRunId','Invoke-EctosQfCurrentRuleFixtureRegression','Invoke-EctosQfCurrentUacPythonTest','Invoke-EctosQfSelfTestCase','Invoke-EctosQfStaticAnalysis','New-EctosQfEvidenceManifest','New-EctosQfEvidenceZip','New-EctosQfOneRunLedger','New-EctosQfWorkspace','Test-EctosQfAssignedAutomaticVariable','Test-EctosQfAuthorityTemplate','Test-EctosQfCurrentEngineeringBinding','Test-EctosQfCurrentHandoffContract','Test-EctosQfCurrentUacContract','Test-EctosQfHarnessContract','Test-EctosQfManifestClosure','Test-EctosQfNativeParse','Test-EctosQfPythonVersionContract','Test-EctosQfRuleSample','Test-EctosQfSha256','Test-EctosQfZipIntegrity','Write-EctosQfRegistryRow'
 )
 CmdletsToExport=@()
 VariablesToExport=@()
 AliasesToExport=@()
}
