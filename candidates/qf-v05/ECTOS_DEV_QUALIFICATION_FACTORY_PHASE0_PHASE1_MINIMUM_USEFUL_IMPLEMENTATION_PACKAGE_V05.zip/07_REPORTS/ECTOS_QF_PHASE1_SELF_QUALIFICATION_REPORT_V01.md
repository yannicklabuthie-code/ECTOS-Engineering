# ECTOS QF Phase 1 Self-Qualification Report V01

## Build-sandbox result

The Phase 0 contracts, modular Phase 1 common-core source, synthetic profile, 25-test native PS5.1 self-test suite, registries and reporting contracts were generated. Package-level integrity and manifest closure are independently verified during package assembly.

## Fail-closed native status

Native Windows PowerShell 5.1 is not installed in the build sandbox. Therefore:

- Native PS5.1 static/runtime proof: **NOT PROVEN**
- Native PS5.1 parse error count: **NOT AVAILABLE**
- Mandatory 25-test native suite: **NOT EXECUTED**
- Phase 1 status: **HOLD_PENDING_NATIVE_PS51_SELF_QUALIFICATION**
- QF maturity: **M0_IMPLEMENTED_NOT_NATIVE_PROVEN**

This is intentionally not converted to PASS. Run `00_CONTROL/RUN_ECTOS_QF_PHASE0_PHASE1_NATIVE_PS51_V01.ps1` under native Windows PowerShell 5.1. The runner uses synthetic/inert fixtures only and does not invoke ECTOS Candidate behavior.
