Set-StrictMode -Version 2.0
function Test-EctosQfHarnessContract {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][hashtable]$Harness)
 $required=@('NAME','INERT_ONLY','CANDIDATE_EXECUTION','PROTECTED_STATE_MUTATION')
 $missing=@($required | Where-Object {-not $Harness.ContainsKey($_)})
 $safe=($missing.Count -eq 0 -and $Harness.INERT_ONLY -eq 'YES' -and $Harness.CANDIDATE_EXECUTION -eq 'NO' -and $Harness.PROTECTED_STATE_MUTATION -eq 'NO')
 [pscustomobject]@{Status=if($safe){'PASS'}else{'FAIL'};MissingCount=$missing.Count;Missing=$missing}
}
