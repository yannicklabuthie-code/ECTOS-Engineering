# UAC Control Plane V02 — Change Impact Analysis

BASELINE_MAIN_SHA=57ffec2cdda7172b9db967b852ff588215108f67
CANDIDATE_COMMIT_SHA=08c6197c51dee49b4f0aeb8787736bcf7bce69ba
CHANGED_FILE_COUNT=17

## Upstream dependencies
Canonical GitHub repository identity; current code-rule selector V02; UAC registry; GitHub governance ruleset contract; package dependency graph contract; authority issuer keys supplied by the execution environment.

## Direct changes
- deterministic staged artifact-path rebasing and ambiguity rejection;
- canonical UTF-8 JSON byte enforcement with BOM/CRLF rejection;
- pre-dispatch worktree-versus-git-blob identity enforcement;
- signed machine-verifiable authority evidence and issuer binding;
- source commit binding in requests, receipts and descriptors;
- persisted authority-evidence nonce replay protection;
- canonical handoff workflow integration of pre-dispatch and staged-path receipts;
- explicit NC01-NC20 regression coverage.

## Downstream impact
Canonical handoff now fails closed when caller assertions lack authoritative evidence, bytes drift from committed objects, staged artifact paths are ambiguous/missing, or evidence is stale/expired/replayed/misbound. External Cloud/Firebase/Flutter runtime qualification remains out of UAC scope. QF V05 is unchanged.

LOCAL_VS_SYSTEMIC=SYSTEMIC_CONTROL_PLANE
