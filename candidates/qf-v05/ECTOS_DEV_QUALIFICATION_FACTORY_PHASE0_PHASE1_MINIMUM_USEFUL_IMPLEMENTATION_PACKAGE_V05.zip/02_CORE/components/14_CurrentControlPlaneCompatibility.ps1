Set-StrictMode -Version 2.0

function Get-EctosQfRulesetAggregateSha256 {
 [CmdletBinding()]
 param([Parameter(Mandatory=$true)][string]$EngineeringRoot)
 $contractPath=Join-Path $EngineeringRoot 'profiles\powershell\ECTOS_AGENT_CONSUMPTION_CONTRACT_V01.json'
 $contract=Get-Content -LiteralPath $contractPath -Raw | ConvertFrom-Json
 $paths=@($contract.retrieve.rule_set | Sort-Object)
 $stream=New-Object System.IO.MemoryStream
 try{
   foreach($relativePath in $paths){
     $pathBytes=[Text.Encoding]::UTF8.GetBytes($relativePath.Replace('\','/'))
     $fileBytes=[IO.File]::ReadAllBytes((Join-Path $EngineeringRoot $relativePath))
     $stream.Write($pathBytes,0,$pathBytes.Length);$stream.WriteByte(0)
     $stream.Write($fileBytes,0,$fileBytes.Length);$stream.WriteByte(0)
   }
   $hashAlgorithm=[Security.Cryptography.SHA256]::Create()
   try{
     $hash=$hashAlgorithm.ComputeHash($stream.ToArray())
     return ([BitConverter]::ToString($hash)).Replace('-','').ToUpperInvariant()
   }finally{$hashAlgorithm.Dispose()}
 }finally{$stream.Dispose()}
}
function Test-EctosQfCurrentEngineeringBinding {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$PackageRoot)
 $engineeringRoot=Join-Path $PackageRoot '01_PROJECT_FREEZE\CURRENT_ENGINEERING'
 $selector=Get-Content -LiteralPath (Join-Path $engineeringRoot 'ECTOS_AGENT_CODE_RULE_SOURCE_POINTER.json') -Raw | ConvertFrom-Json
 if($selector.current_pointer -ne 'ECTOS_AGENT_CODE_RULE_SOURCE_POINTER_V02.json'){throw 'QF_CURRENT_SELECTOR_MISMATCH'}
 $pointer=Get-Content -LiteralPath (Join-Path $engineeringRoot $selector.current_pointer) -Raw | ConvertFrom-Json
 if($pointer.status -ne 'CURRENT' -or $pointer.repository -ne 'yannicklabuthie-code/ECTOS-Engineering' -or $pointer.branch -ne 'main'){throw 'QF_CURRENT_POINTER_MISMATCH'}
 $profileObject=Get-Content -LiteralPath (Join-Path $engineeringRoot 'profiles\powershell\ECTOS_POWERSHELL_PS51_PROFILE.json') -Raw | ConvertFrom-Json
 if($profileObject.profile_sha256 -ne '4B9A8830292CC811B141B4DAE91F2B816A3448921EE3B3ED25DA412C17A78625'){throw 'QF_PROFILE_IDENTITY_MISMATCH'}
 $aggregate=Get-EctosQfRulesetAggregateSha256 -EngineeringRoot $engineeringRoot
 if($aggregate -ne '2FD86D22587B2E694FC62C3B734DED1A7430831BFC0E34B5C176327012907525'){throw 'QF_RULESET_IDENTITY_MISMATCH'}
 [pscustomobject]@{Status='PASS';CurrentPointer=$selector.current_pointer;ProfileSha256=$profileObject.profile_sha256;RulesetSha256=$aggregate;RuleCount=10}
}
function Test-EctosQfRuleSample {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$RuleId,[Parameter(Mandatory=$true)][string]$Sample)
 switch($RuleId){
   'PS51-R001' { return [bool]($Sample -match '\$[A-Za-z_][A-Za-z0-9_]*:') }
   'PS51-R002' { return [bool]($Sample -match '=\s*if\s*\(') }
   'PS51-R003' {
     $sampleTokens=$null;$sampleErrors=$null
     $sampleAst=[System.Management.Automation.Language.Parser]::ParseInput($Sample,[ref]$sampleTokens,[ref]$sampleErrors)
     $sampleParameters=@($sampleAst.FindAll({param($node) $node -is [System.Management.Automation.Language.ParameterAst]},$true))
     foreach($sampleParameter in $sampleParameters){
       if($null -ne $sampleParameter.DefaultValue){
         $sampleVariables=@($sampleParameter.DefaultValue.FindAll({param($node) $node -is [System.Management.Automation.Language.VariableExpressionAst]},$true))
         if(@($sampleVariables | Where-Object { $_.VariablePath.UserPath -eq 'PSScriptRoot' }).Count -gt 0){return $true}
       }
     }
     return $false
   }
   'PS51-R004' { return [bool]($Sample -match '(?i)Get-ChildItem.*-ErrorAction\s+SilentlyContinue') }
   'PS51-R005' { return [bool]($Sample -match 'SCAN_SCOPE=REPOSITORY_ROOT') }
   'PS51-R006' { return [bool]($Sample -match '(?i)\$PID\s*=') }
   'PS51-R007' { return [bool]($Sample -match 'Select-Object\s*-First\s*1') }
   'PS51-R008' { return [bool]($Sample -match 'Invoke-Target.* \$GenericList') }
   'PS51-R009' { return [bool](($Sample -match '\$mode\s*=\s*"Safe"') -and ($Sample -notmatch '\[MyEnum\]')) }
   'PS51-R010' { return [bool]($Sample -match '\$[A-Za-z_][A-Za-z0-9_]*:') }
   default { throw ('QF_UNKNON_RULE_ID '+$RuleId) }
 }
}
function Invoke-EctosQfCurrentRuleFixtureRegression {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$PackageRoot)
 $engineeringRoot=Join-Path $PackageRoot '01_PROJECT_FREEZE\CURRENT_ENGINEERING'
 $positive=Get-Content -LiteralPath (Join-Path $engineeringRoot 'fixtures\powershell\positive\PS51_POSITIVE_FIXTURES_V01.json') -Raw | ConvertFrom-Json
 $negative=Get-Content -LiteralPath (Join-Path $engineeringRoot 'fixtures\powershell\negative\PS51_NEGATIVE_FIXTURES_V01.json') -Raw | ConvertFrom-Json
 $rows=@()
 foreach($case in @($positive.cases)){$detected=Test-EctosQfRuleSample -RuleId $case.rule_id -Sample $case.sample;$rows += [pscustomobject]@{FixtureId=$case.fixture_id;RuleId=$case.rule_id;Expected='PASS';Detected=$detected;Status=$(if(-not $detected){'PASS'}else{'FAIL'})}}
 foreach($case in @($negative.cases)){$detected=Test-EctosQfRuleSample -RuleId $case.rule_id -Sample $case.sample;$rows += [pscustomobject]@{FixtureId=$case.fixture_id;RuleId=$case.rule_id;Expected='FAIL';Detected=$detected;Status=$(if($detected){'PASS'}else{'FAIL'})}}
 $failCount=@($rows | Where-Object { $_.Status -eq 'FAIL' }).Count
 [pscustomobject]@{Status=$(if($failCount -eq 0){'PASS'}else{'FAIL'});CaseCount=$rows.Count;FailCount=$failCount;Rows=$rows}
}
function Test-EctosQfCurrentUacContract {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$PackageRoot)
 $uacRoot=Join-Path $PackageRoot '01_PROJECT_FREEZE\CURRENT_UAC\uac'
 $registry=Get-Content -LiteralPath (Join-Path $uacRoot 'config\registry.json') -Raw | ConvertFrom-Json
 if($registry.default_policy -ne 'DENY'){throw 'QF_UAC_DEFAULT_POLICY_NOT_DENY'}
 $coreText=[IO.File]::ReadAllText((Join-Path $uacRoot 'uac_core.py'))
 $requiredTokens=@('project','mission_id','failure_family_id','actor','qualifier','systemic_assurance_id','package_id','package_sha256','manifest_sha256','dependency_graph_sha256','dependency_closure','undeclared_dependency_count','unresolved_transitive_dependency_count','untested_dependency_count','implicit_environment_assumption_count','unknown_blast_radius_edge_count','target','action','qualification_result','systemic_review_state','consolidated_defect_set_state','governance_currentness','rule_source_currentness','negative_controls','circuit_breaker_state','SELF_ADMISSION_PROHIBITED','PRODUCER_OR_ACTOR_CANNOT_BE_ITS_OWN_QUALIFIER','SYSTEMIC_ASSURANCE_SEPARATION_VIOLATION','RECEIPT_REPLAY_DETECTED')
 $missing=@();foreach($token in $requiredTokens){if($coreText.IndexOf($token,[StringComparison]::Ordinal) -lt 0){$missing += $token}}
 if($missing.Count -gt 0){throw ('QF_UAC_CONTRACT_TOKENS_MISSING '+($missing -join ','))}
 [pscustomobject]@{Status='PASS';DefaultPolicy='DENY';RequiredTokenCount=$requiredTokens.Count;MissingTokenCount=0}
}
function Test-EctosQfCurrentHandoffContract {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$PackageRoot)
 $contract=Get-Content -LiteralPath (Join-Path $PackageRoot '07_REPORTS\ECTOS_QF_CHANGE_RELEASE_OUTPUT_CONTRACT_V02.json') -Raw | ConvertFrom-Json
 if($contract.handoff_schema -ne 'ECTOS_CANONICAL_HANDOFF_V01'){throw 'QF_HANDOFF_SCHEMA_MISMATCH'}
 if($contract.handoff_state -ne 'PACKAGE_READY_FOR_HANDOFF'){throw 'QF_HANDOFF_STATE_MISMATCH'}
 if($contract.handoff_target -ne 'ECTOS_PACKAGE_HANDOFF'){throw 'QF_HANDOFF_TARGET_MISMATCH'}
 if($contract.handoff_action -ne 'ISSUE_HANDOFF'){throw 'QF_HANDOFF_ACTION_MISMATCH'}
 $required=@('PACKAGE_NAME','PACKAGE_SHA256','MANIFEST_NAME','MANIFEST_SHA256','DEPENDENCY_GRAPH_SHA256','DEPENDENCY_CLOSURE','SOURCE_COMMIT_SHA','SOURCE_REPOSITORY','GOVERNANCE_ATTESTATION_SHA256','UAC_RECEIPT','RECEIPT_ID','RECEIPT_VERSION','RECEIPT_ISSUER_ID','ADMISSION_TARGET','ADMISSION_ACTION')
 $missing=@($required | Where-Object { $_ -notin @($contract.required_fields) })
 if($missing.Count -gt 0){throw ('QF_HANDOFF_FIELDS_MISSING '+($missing -join ','))}
 [pscustomobject]@{Status='PASS';RequiredFieldCount=$required.Count;MissingFieldCount=0}
}
function Test-EctosQfPythonVersionContract {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][Version]$Version)
 $ok=($Version.Major -eq 3 -and $Version.Minor -ge 12 -and $Version.Major -lt 4)
 [pscustomobject]@{Status=$(if($ok){'PASS'}else{'FAIL'});Version=$Version.ToString();Minimum='3.12';MaximumExclusive='4.0'}
}
function Invoke-EctosQfCurrentUacPythonTest {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$PackageRoot)
 $uacRoot=Join-Path $PackageRoot '01_PROJECT_FREEZE\CURRENT_UAC\uac'
 $pythonCommand=Get-Command python -ErrorAction Stop
 $versionText=& $pythonCommand.Source -c "import sys; print('.'.join(map(str,sys.version_info[:3])))"
 if($LASTEXITCODE -ne 0){throw 'QF_PYTHON_VERSION_PROBE_FAIL'}
 $versionResult=Test-EctosQfPythonVersionContract -Version ([Version]$versionText.Trim())
 if($versionResult.Status -ne 'PASS'){throw ('QF_PYTHON_VERSION_UNSUPPORTED '+$versionResult.Version)}
 $processInfo=New-Object Diagnostics.ProcessStartInfo
 $processInfo.FileName=$pythonCommand.Source
 $processInfo.WorkingDirectory=$uacRoot
 $processInfo.Arguments='-m unittest discover -s tests -v'
 $processInfo.UseShellExecute=$false
 $processInfo.RedirectStandardOutput=$true
 $processInfo.RedirectStandardError=$true
 $process=New-Object Diagnostics.Process
 $process.StartInfo=$processInfo
 if(-not $process.Start()){throw 'QF_UAC_PYTHON_TEST_START_FAILURE'}
 try{
   $stopwatch=[Diagnostics.Stopwatch]::StartNew()
   $stdoutTask=$process.StandardOutput.ReadToEndAsync()
   $stderrTask=$process.StandardError.ReadToEndAsync()
   if(-not $process.WaitForExit(10000)){try{$process.Kill()}catch{Write-Verbose $_.Exception.Message};throw 'QF_UAC_PYTHON_TEST_TIMEOUT'}
   $process.WaitForExit()
   $stdout=$stdoutTask.Result
   $stderr=$stderrTask.Result
   $stopwatch.Stop()
   if($process.ExitCode -ne 0){throw ('QF_UAC_PYTHON_TEST_FAIL '+$process.ExitCode+' '+$stderr)}
   [pscustomobject]@{Status='PASS';ExitCode=$process.ExitCode;RuntimeMs=$stopwatch.ElapsedMilliseconds;Stdout=$stdout;Stderr=$stderr;StdoutCharCount=$stdout.Length;StderrCharCount=$stderr.Length;PipeDrainMode='ASYNC_BEFORE_WAIT'}
 }finally{$process.Dispose()}
}