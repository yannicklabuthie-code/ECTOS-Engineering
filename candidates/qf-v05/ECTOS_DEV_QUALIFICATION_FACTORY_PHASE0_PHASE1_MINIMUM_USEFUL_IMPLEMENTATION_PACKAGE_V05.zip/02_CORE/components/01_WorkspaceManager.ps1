Set-StrictMode -Version 2.0
function New-EctosQfWorkspace {
    [CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact='Low')]
    param([string]$Root = 'C:\EQ')
    $directoryNames = @('00_INTAKE','01_STAGE','02_STATIC','03_NATIVE','04_HARNESS','05_BEHAVIORAL','06_PROTECTED_STATE','07_EVIDENCE','08_AUTHORITY','09_RELEASE','CORE','PROFILES','SELFTEST','LOGS','REGISTRY')
    if ([string]::IsNullOrWhiteSpace($Root)) { throw 'QF_WORKSPACE_ROOT_EMPTY' }
    foreach($directoryName in $directoryNames){
        $directoryPath=Join-Path $Root $directoryName
        if(-not (Test-Path -LiteralPath $directoryPath)){
            if($PSCmdlet.ShouldProcess($directoryPath,'Create qualification workspace directory')){
                New-Item -ItemType Directory -Path $directoryPath -Force | Out-Null
            }
        }
    }
    [pscustomobject]@{ Root=$Root; DirectoryCount=$directoryNames.Count; Status='READY' }
}
