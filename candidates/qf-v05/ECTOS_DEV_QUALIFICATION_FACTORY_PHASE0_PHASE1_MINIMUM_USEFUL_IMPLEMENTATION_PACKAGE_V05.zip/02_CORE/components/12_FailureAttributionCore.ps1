Set-StrictMode -Version 2.0
function Get-EctosQfFailureAttribution {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$FailureCode,[string]$Detail='')
 $map=@{'QF_F_INPUT'='Q0_INPUT';'QF_F_ZIP'='Q1_PACKAGE';'QF_F_STATIC'='Q2_SOURCE';'QF_F_NATIVE'='Q3_NATIVE';'QF_F_HARNESS'='Q4_HARNESS';'QF_F_AUTHORITY'='Q4_AUTHORITY';'QF_F_EVIDENCE'='Q6_EVIDENCE';'QF_F_PROTECTED_STATE'='Q4_PROTECTED_STATE'}
 $owner=if($map.ContainsKey($FailureCode)){$map[$FailureCode]}else{'UNRESOLVED'}
 [pscustomobject]@{FailureCode=$FailureCode;Attribution=$owner;Detail=$Detail;Status=if($owner -eq 'UNRESOLVED'){'BLOCKED'}else{'ATTRIBUTED'}}
}
