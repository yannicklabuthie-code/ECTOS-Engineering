[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)]
 [ValidatePattern('^[A-Fa-f0-9]{64}$')]
 [string]$ExactPackageSha256
)
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
$Here=Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageRoot=Split-Path -Parent $Here
Import-Module (Join-Path $PackageRoot '02_CORE\ECTOS.QF.Core.psd1') -Force
Write-Output '=== ECTOS DEV - QUALIFICATION FACTORY PHASE0/1 V05 ==='
Write-Output 'CANDIDATE_BEHAVIORAL_EXECUTION=NO'
Write-Output 'REAL_ECTOS_OS_MUTATION=NO'
Write-Output 'REAL_REPOSITORY_PROTECTED_STATE_MUTATION=NO'
Write-Output 'RELEASE_PROMOTION=NO'
$nativeResult=Assert-EctosQfNativeWindowsPowerShell51
Write-Output ('NATIVE_PS51_STATUS='+$nativeResult.Status)
$workspace=New-EctosQfWorkspace -Root 'C:\EQ' -Confirm:$false
Write-Output ('CANONICAL_ROOT='+$workspace.Root)
& (Join-Path $PackageRoot '04_SELFTEST\RUN_ECTOS_QF_SELFTEST_NATIVE_PS51_V05.ps1') -ExactPackageSha256 $ExactPackageSha256
Write-Output 'NEXT_GATE=ECTOS_QF_V05_MAIN_AUTHORITY_REVIEW'
Write-Output 'POWERSHELL_SESSION_REMAINS_OPEN=YES'
