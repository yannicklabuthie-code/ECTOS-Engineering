Set-StrictMode -Version 2.0
function New-EctosQfEvidenceManifest {
 [CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact='Low')]
 param([Parameter(Mandatory=$true)][string]$Root,[Parameter(Mandatory=$true)][string]$OutputCsv)
 $resolved=(Resolve-Path -LiteralPath $Root).Path
 $rows=@(Get-ChildItem -LiteralPath $resolved -Recurse -File | Where-Object {$_.FullName -ne $OutputCsv} | ForEach-Object {
   $relativePath=$_.FullName.Substring($resolved.Length).TrimStart('\','/').Replace('\','/')
   [pscustomobject]@{RELATIVE_PATH=$relativePath;SIZE_BYTES=[int64]$_.Length;SHA256=(Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash.ToUpperInvariant()}
 })
 if($PSCmdlet.ShouldProcess($OutputCsv,'Write evidence manifest')){$rows | Sort-Object RELATIVE_PATH | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $OutputCsv}
 return $rows
}
function New-EctosQfEvidenceZip {
 [CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact='Low')]
 param([Parameter(Mandatory=$true)][string]$SourceRoot,[Parameter(Mandatory=$true)][string]$ZipPath)
 Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction Stop
 if(Test-Path -LiteralPath $ZipPath){throw 'QF_EVIDENCE_ZIP_ALREADY_EXISTS'}
 if($PSCmdlet.ShouldProcess($ZipPath,'Create evidence zip')){[System.IO.Compression.ZipFile]::CreateFromDirectory($SourceRoot,$ZipPath,[System.IO.Compression.CompressionLevel]::Optimal,$false)}
 Get-EctosQfByteIdentity -Path $ZipPath
}
