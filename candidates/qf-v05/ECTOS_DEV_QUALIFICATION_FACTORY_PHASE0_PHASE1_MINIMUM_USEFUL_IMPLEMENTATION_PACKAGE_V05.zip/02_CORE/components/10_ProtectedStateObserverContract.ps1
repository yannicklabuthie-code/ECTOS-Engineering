Set-StrictMode -Version 2.0
function Get-EctosQfProtectedStateSnapshot {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][string[]]$Paths)
 $rows=@()
 foreach($pathValue in $Paths){
   if(-not(Test-Path -LiteralPath $pathValue)){throw ('QF_PROTECTED_STATE_OBSERVATION_FAILURE '+$pathValue)}
   $item=Get-Item -LiteralPath $pathValue
   $lengthValue=0;$shaValue=''
   if(-not $item.PSIsContainer){$lengthValue=$item.Length;$shaValue=(Get-FileHash -Algorithm SHA256 -LiteralPath $item.FullName).Hash.ToUpperInvariant()}
   $rows += [pscustomobject]@{Path=$item.FullName;Length=$lengthValue;LastWriteTimeUtc=$item.LastWriteTimeUtc.ToString('o');SHA256=$shaValue}
 }
 return $rows
}
function Compare-EctosQfProtectedStateSnapshot {
 [CmdletBinding()] param($Before,$After)
 $beforeJson=($Before | ConvertTo-Json -Depth 6 -Compress);$afterJson=($After | ConvertTo-Json -Depth 6 -Compress)
 [pscustomobject]@{Status=$(if($beforeJson -eq $afterJson){'PASS'}else{'FAIL'});MutationDetected=($beforeJson -ne $afterJson)}
}
