[Console]::Error.Write('INERT_STDERR')
