Set-StrictMode -Version 2.0
function Test-EctosQfZipIntegrity {
    [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$Path)
    Add-Type -AssemblyName System.IO.Compression -ErrorAction Stop
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    $stream=$null; $zip=$null
    try {
      $stream=[System.IO.File]::OpenRead($Path)
      $zip=New-Object System.IO.Compression.ZipArchive($stream,[System.IO.Compression.ZipArchiveMode]::Read,$false)
      $names=@{}; $dup=@(); $trav=@(); $count=0
      foreach($e in $zip.Entries){
        $count++
        $n=$e.FullName.Replace('\\','/')
        $key=$n.ToLowerInvariant()
        if($names.ContainsKey($key)){ $dup += $n } else { $names[$key]=$true }
        $parts=$n.Split('/')
        if($n.StartsWith('/') -or $n -match '^[A-Za-z]:' -or ($parts -contains '..')){ $trav += $n }
        if(-not [string]::IsNullOrEmpty($e.Name)){
          $s=$e.Open(); try { $buf=New-Object byte[] 8192; while($s.Read($buf,0,$buf.Length) -gt 0){} } finally { $s.Dispose() }
        }
      }
      [pscustomobject]@{ Status=if($dup.Count -eq 0 -and $trav.Count -eq 0){'PASS'}else{'FAIL'}; EntryCount=$count; DuplicateCount=$dup.Count; TraversalCount=$trav.Count; DuplicateMembers=$dup; TraversalMembers=$trav }
    } finally { if($zip){$zip.Dispose()}; if($stream){$stream.Dispose()} }
}
function Test-EctosQfManifestClosure {
    [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$Root,[Parameter(Mandatory=$true)][string]$ManifestPath)
    if(-not (Test-Path -LiteralPath $ManifestPath)){ throw 'QF_MANIFEST_MISSING' }
    $rows=Import-Csv -LiteralPath $ManifestPath
    $expected=@{}; foreach($r in $rows){ $expected[$r.RELATIVE_PATH.Replace('\\','/').ToLowerInvariant()]=$r }
    $actual=Get-ChildItem -LiteralPath $Root -Recurse -File | Where-Object { $_.FullName -ne (Resolve-Path -LiteralPath $ManifestPath).Path }
    $missing=@(); $extra=@(); $hashFail=@(); $sizeFail=@()
    foreach($f in $actual){
      $rel=$f.FullName.Substring((Resolve-Path -LiteralPath $Root).Path.Length).TrimStart('\','/').Replace('\','/')
      $key=$rel.ToLowerInvariant(); if(-not $expected.ContainsKey($key)){ $extra += $rel; continue }
      $r=$expected[$key]
      if([int64]$r.SIZE_BYTES -ne [int64]$f.Length){$sizeFail += $rel}
      $h=(Get-FileHash -Algorithm SHA256 -LiteralPath $f.FullName).Hash.ToUpperInvariant(); if($h -ne $r.SHA256.ToUpperInvariant()){$hashFail += $rel}
      $expected.Remove($key)
    }
    foreach($k in $expected.Keys){$missing += $expected[$k].RELATIVE_PATH}
    [pscustomobject]@{ Status=if($missing.Count+$extra.Count+$hashFail.Count+$sizeFail.Count -eq 0){'PASS'}else{'FAIL'}; MissingCount=$missing.Count; ExtraCount=$extra.Count; HashFailureCount=$hashFail.Count; SizeFailureCount=$sizeFail.Count; Missing=$missing; Extra=$extra; HashFailures=$hashFail; SizeFailures=$sizeFail }
}
