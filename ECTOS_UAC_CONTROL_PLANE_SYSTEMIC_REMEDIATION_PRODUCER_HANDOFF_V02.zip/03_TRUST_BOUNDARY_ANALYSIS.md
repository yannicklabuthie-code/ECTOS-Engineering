# UAC V02 — Trust Boundary Analysis

PRODUCER != QUALIFIER != SYSTEMIC_ASSURANCE != ADMISSION_AUTHORITY.

Caller state is not authoritative. The UAC requires signed evidence for independent qualification, systemic assurance, consolidated defect closure, circuit-breaker clearance, rule-source currentness, and negative controls. Evidence is bound to package ID/hash, manifest hash, dependency graph hash, repository, source commit, mission, failure family, actor, qualifier, systemic assurance identity, admission authority, target and action. Trusted key IDs and trusted issuer IDs are registry-governed. Expiry and nonce replay are fail-closed. The canonical signing key remains central-only in the canonical handoff workflow.

No external deployment action was added. No authority responsibility was relocated downstream.
