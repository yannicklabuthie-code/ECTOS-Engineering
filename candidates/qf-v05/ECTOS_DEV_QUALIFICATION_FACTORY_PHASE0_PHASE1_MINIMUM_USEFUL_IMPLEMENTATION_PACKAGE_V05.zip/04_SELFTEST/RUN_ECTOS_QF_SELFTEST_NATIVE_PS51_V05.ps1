[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)]
 [ValidatePattern('^[A-Fa-f0-9]{64}$')]
 [string]$ExactPackageSha256
)
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
$Here=Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageRoot=Split-Path -Parent $Here
$Core=Join-Path $PackageRoot '02_CORE\ECTOS.QF.Core.psd1'
Import-Module $Core -Force
$Native=Assert-EctosQfNativeWindowsPowerShell51
$normalizedPackageSha256=$ExactPackageSha256.ToUpperInvariant()
$Seed=('ECTOS-QF-SELFTEST-V05|'+$normalizedPackageSha256)
$RunId=Get-EctosQfRunId -Seed $Seed
$Root=Join-Path 'C:\EQ\SELFTEST' $RunId
if(Test-Path -LiteralPath $Root){throw 'QF_V05_SELFTEST_RUN_ALREADY_EXISTS_NO_RETRY'}
New-Item -ItemType Directory -Path $Root -Force | Out-Null
$Results=@()
function Add-EctosQfTestResult {
 [CmdletBinding()] param([string]$Name,[scriptblock]$Body)
 $script:Results += Invoke-EctosQfSelfTestCase -Name $Name -Body $Body
}
Add-EctosQfTestResult 'SELF_PARSE_TEST' {
 $paths=@(Get-ChildItem (Join-Path $PackageRoot '02_CORE') -Recurse -File | Where-Object {$_.Extension -in @('.ps1','.psm1','.psd1')} | ForEach-Object {$_.FullName})
 $result=Test-EctosQfNativeParse -Paths $paths
 if($result.ParseErrorCount -ne 0){throw ('PARSE_ERRORS='+$result.ParseErrorCount)}
}
Add-EctosQfTestResult 'EMPTY_FILE_TEST' {
 $pathValue=Join-Path $Root 'empty.txt';[IO.File]::WriteAllBytes($pathValue,(New-Object byte[] 0));$identity=Get-EctosQfByteIdentity $pathValue
 if($identity.SizeBytes -ne 0){throw 'EMPTY_FILE_SIZE_NOT_ZERO'}
}
Add-EctosQfTestResult 'EMPTY_COLLECTION_TEST' {$items=@();if(@($items).Count -ne 0){throw 'EMPTY_COLLECTION_NOT_EMPTY'}}
Add-EctosQfTestResult 'MISSING_MEMBER_TEST' {
 $directory=Join-Path $Root 'missing';New-Item -ItemType Directory -Path $directory|Out-Null
 $manifest=Join-Path $directory 'MANIFEST.csv'
 [IO.File]::WriteAllText($manifest,"RELATIVE_PATH,SIZE_BYTES,SHA256`r`nmissing.txt,0,E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855",[Text.Encoding]::ASCII)
 $result=Test-EctosQfManifestClosure -Root $directory -ManifestPath $manifest
 if($result.MissingCount -ne 1){throw 'MISSING_NOT_DETECTED'}
}
Add-EctosQfTestResult 'HASH_MISMATCH_TEST' {
 $pathValue=Join-Path $Root 'hash.txt';'x'|Set-Content -LiteralPath $pathValue -NoNewline -Encoding ASCII
 $result=Test-EctosQfSha256 -Path $pathValue -ExpectedSha256 ('0'*64)
 if($result.Status -ne 'FAIL'){throw 'HASH_MISMATCH_NOT_DETECTED'}
}
Add-EctosQfTestResult 'ZIP_STREAM_TEST' {
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 $directory=Join-Path $Root 'zipstream';New-Item -ItemType Directory -Path $directory|Out-Null;'ok'|Set-Content (Join-Path $directory 'a.txt') -NoNewline
 $zipPath=Join-Path $Root 'stream.zip';[IO.Compression.ZipFile]::CreateFromDirectory($directory,$zipPath)
 $result=Test-EctosQfZipIntegrity $zipPath;if($result.Status -ne 'PASS'){throw 'ZIP_STREAM_FAIL'}
}
Add-EctosQfTestResult 'ZIP_DUPLICATE_MEMBER_TEST' {
 Add-Type -AssemblyName System.IO.Compression
 $zipPath=Join-Path $Root 'dup.zip';$fileStream=[IO.File]::Open($zipPath,[IO.FileMode]::Create)
 try{$archive=New-Object IO.Compression.ZipArchive($fileStream,[IO.Compression.ZipArchiveMode]::Create,$false);try{[void]$archive.CreateEntry('A.txt');[void]$archive.CreateEntry('a.txt')}finally{$archive.Dispose()}}finally{$fileStream.Dispose()}
 $result=Test-EctosQfZipIntegrity $zipPath;if($result.DuplicateCount -lt 1){throw 'DUPLICATE_NOT_DETECTED'}
}
Add-EctosQfTestResult 'ZIP_PATH_TRAVERSAL_TEST' {
 Add-Type -AssemblyName System.IO.Compression
 $zipPath=Join-Path $Root 'trav.zip';$fileStream=[IO.File]::Open($zipPath,[IO.FileMode]::Create)
 try{$archive=New-Object IO.Compression.ZipArchive($fileStream,[IO.Compression.ZipArchiveMode]::Create,$false);try{[void]$archive.CreateEntry('../escape.txt')}finally{$archive.Dispose()}}finally{$fileStream.Dispose()}
 $result=Test-EctosQfZipIntegrity $zipPath;if($result.TraversalCount -lt 1){throw 'TRAVERSAL_NOT_DETECTED'}
}
Add-EctosQfTestResult 'LONG_PATH_TEST' {$pathValue='C:\EQ\'+('x'*270);if($pathValue.Length -le 260){throw 'LONG_PATH_FIXTURE_INVALID'}}
Add-EctosQfTestResult 'CASE_COLLISION_TEST' {$names=@('Foo.txt','foo.txt');$groups=$names|Group-Object {$_.ToLowerInvariant()}|Where-Object {$_.Count -gt 1};if(@($groups).Count -ne 1){throw 'CASE_COLLISION_NOT_DETECTED'}}
Add-EctosQfTestResult 'VARIABLE_COLLISION_TEST' {
 $pathValue=Join-Path $Root 'autovar.ps1';[IO.File]::WriteAllText($pathValue,'$PID=42',[Text.Encoding]::ASCII)
 $result=Invoke-EctosQfStaticAnalysis $pathValue
 if($result.AutomaticReservedVariableCollisionCount -lt 1 -or $result.ActiveRuleHits -notcontains 'PS51-R006'){throw 'AUTOMATIC_VARIABLE_COLLISION_NOT_DETECTED'}
}
Add-EctosQfTestResult 'SINGLE_LETTER_HELPER_TEST' {
 $pathValue=Join-Path $Root 'single.ps1';'function x { 1 }'|Set-Content $pathValue -Encoding ASCII
 $result=Invoke-EctosQfStaticAnalysis $pathValue;if($result.SingleLetterHelperCount -lt 1){throw 'SINGLE_HELPER_NOT_DETECTED'}
}
Add-EctosQfTestResult 'MALFORMED_TOKEN_TEST' {
 $pathValue=Join-Path $Root 'bad.ps1';'function Test-X { if ( }'|Set-Content $pathValue -Encoding ASCII
 $result=Invoke-EctosQfStaticAnalysis $pathValue;if($result.ParseErrorCount -lt 1){throw 'MALFORMED_NOT_DETECTED'}
}
Add-EctosQfTestResult 'AUTHORITY_ABSENT_TEST' {$result=Test-EctosQfAuthorityTemplate -Authority $null;if($result.Reason -ne 'AUTHORITY_ABSENT'){throw 'ABSENT_AUTHORITY_NOT_DETECTED'}}
Add-EctosQfTestResult 'AUTHORITY_INACTIVE_TEST' {$result=Test-EctosQfAuthorityTemplate @{AUTHORITY_ID='A';ACTIVE='NO';CONSUMED='NO';SCOPE='SYNTHETIC'};if($result.Reason -ne 'AUTHORITY_INACTIVE'){throw 'INACTIVE_NOT_DETECTED'}}
Add-EctosQfTestResult 'AUTHORITY_ALREADY_CONSUMED_TEST' {$result=Test-EctosQfAuthorityTemplate @{AUTHORITY_ID='A';ACTIVE='YES';CONSUMED='YES';SCOPE='SYNTHETIC'};if($result.Reason -ne 'AUTHORITY_ALREADY_CONSUMED'){throw 'CONSUMED_NOT_DETECTED'}}
Add-EctosQfTestResult 'PRE_AUTHORITY_FAILURE_TEST' {$h=@{NAME='H';INERT_ONLY='NO';CANDIDATE_EXECUTION='NO';PROTECTED_STATE_MUTATION='NO'};$result=Test-EctosQfHarnessContract $h;if($result.Status -ne 'FAIL'){throw 'PRE_AUTHORITY_FAILURE_NOT_CLOSED'}}
Add-EctosQfTestResult 'PROCESS_START_FAILURE_TEST_INERT_CHILD_ONLY' {
 $processInfo=New-Object Diagnostics.ProcessStartInfo;$processInfo.FileName='__ECTOS_QF_NONEXISTENT_INERT_CHILD__.exe';$processInfo.UseShellExecute=$false;$failed=$false
 try{[Diagnostics.Process]::Start($processInfo)|Out-Null}catch{$failed=$true}
 if(-not $failed){throw 'PROCESS_START_FAILURE_NOT_OBSERVED'}
}
Add-EctosQfTestResult 'STDOUT_EMPTY_TEST_INERT_CHILD_ONLY' {
 $child=Join-Path $Here 'fixtures\inert_child_empty_stdout.ps1'
 $processInfo=New-Object Diagnostics.ProcessStartInfo;$processInfo.FileName='powershell.exe';$processInfo.Arguments=('-NoProfile -ExecutionPolicy Bypass -File "'+$child+'"');$processInfo.UseShellExecute=$false;$processInfo.RedirectStandardOutput=$true;$processInfo.RedirectStandardError=$true
 $process=New-Object Diagnostics.Process;$process.StartInfo=$processInfo;if(-not $process.Start()){throw 'CHILD_START_FAIL'}
 try{if(-not $process.WaitForExit(30000)){try{$process.Kill()}catch{Write-Verbose $_.Exception.Message};throw 'CHILD_TIMEOUT'};$stdout=$process.StandardOutput.ReadToEnd();$stderr=$process.StandardError.ReadToEnd();if(-not [string]::IsNullOrEmpty($stdout)){throw 'STDOUT_NOT_EMPTY'};if($stderr -ne 'INERT_STDERR'){throw ('STDERR_UNEXPECTED='+$stderr)}}finally{$process.Dispose()}
}
Add-EctosQfTestResult 'STDERR_EMPTY_TEST_INERT_CHILD_ONLY' {
 $child=Join-Path $Here 'fixtures\inert_child_empty_stderr.ps1'
 $processInfo=New-Object Diagnostics.ProcessStartInfo;$processInfo.FileName='powershell.exe';$processInfo.Arguments=('-NoProfile -ExecutionPolicy Bypass -File "'+$child+'"');$processInfo.UseShellExecute=$false;$processInfo.RedirectStandardOutput=$true;$processInfo.RedirectStandardError=$true
 $process=New-Object Diagnostics.Process;$process.StartInfo=$processInfo;if(-not $process.Start()){throw 'CHILD_START_FAIL'}
 try{if(-not $process.WaitForExit(30000)){try{$process.Kill()}catch{Write-Verbose $_.Exception.Message};throw 'CHILD_TIMEOUT'};$stdout=$process.StandardOutput.ReadToEnd();$stderr=$process.StandardError.ReadToEnd();if(-not [string]::IsNullOrEmpty($stderr)){throw 'STDERR_NOT_EMPTY'};if($stdout -ne 'INERT_STDOUT'){throw ('STDOUT_UNEXPECTED='+$stdout)}}finally{$process.Dispose()}
}
Add-EctosQfTestResult 'OUTPUT_MISSING_TEST_INERT_CHILD_ONLY' {$pathValue=Join-Path $Root 'missing_output.json';if(Test-Path $pathValue){throw 'FIXTURE_UNEXPECTED'};if(Test-Path $pathValue){throw 'MISSING_OUTPUT_NOT_DETECTED'}}
Add-EctosQfTestResult 'OUTPUT_PARSE_FAILURE_TEST_INERT_CHILD_ONLY' {$pathValue=Join-Path $Root 'bad.json';'{bad'|Set-Content $pathValue -Encoding ASCII;$failed=$false;try{Get-Content $pathValue -Raw|ConvertFrom-Json|Out-Null}catch{$failed=$true};if(-not $failed){throw 'PARSE_FAILURE_NOT_DETECTED'}}
Add-EctosQfTestResult 'PROTECTED_STATE_OBSERVATION_FAILURE_TEST_SYNTHETIC_ONLY' {$failed=$false;try{Get-EctosQfProtectedStateSnapshot -Paths @(Join-Path $Root 'does_not_exist')|Out-Null}catch{$failed=$true};if(-not $failed){throw 'OBSERVATION_FAILURE_NOT_DETECTED'}}
Add-EctosQfTestResult 'EVIDENCE_PACKAGING_FAILURE_TEST' {$zipPath=Join-Path $Root 'preexisting.zip';'x'|Set-Content $zipPath;$failed=$false;try{New-EctosQfEvidenceZip -SourceRoot $Root -ZipPath $zipPath -Confirm:$false|Out-Null}catch{$failed=$true};if(-not $failed){throw 'EVIDENCE_PACKAGING_FAILURE_NOT_DETECTED'}}
Add-EctosQfTestResult 'FAILURE_ATTRIBUTION_TEST' {$result=Get-EctosQfFailureAttribution -FailureCode 'QF_F_NATIVE';if($result.Attribution -ne 'Q3_NATIVE' -or $result.Status -ne 'ATTRIBUTED'){throw 'FAILURE_ATTRIBUTION_WRONG'}}
Add-EctosQfTestResult 'CURRENT_ENGINEERING_BINDING_TEST' {$result=Test-EctosQfCurrentEngineeringBinding -PackageRoot $PackageRoot;if($result.Status -ne 'PASS'){throw 'CURRENT_ENGINEERING_BINDING_FAIL'}}
Add-EctosQfTestResult 'CURRENT_RULE_FIXTURE_REGRESSION_TEST' {$result=Invoke-EctosQfCurrentRuleFixtureRegression -PackageRoot $PackageRoot;if($result.Status -ne 'PASS' -or $result.CaseCount -ne 20){throw ('CURRENT_RULE_FIXTURE_FAIL='+$result.FailCount)}}
Add-EctosQfTestResult 'CURRENT_UAC_CONTRACT_TEST' {$result=Test-EctosQfCurrentUacContract -PackageRoot $PackageRoot;if($result.Status -ne 'PASS'){throw 'CURRENT_UAC_CONTRACT_FAIL'}}
Add-EctosQfTestResult 'CURRENT_UAC_PYTHON_TESTS' {$actual=Invoke-EctosQfCurrentUacPythonTest -PackageRoot $PackageRoot;if($actual.Status -ne 'PASS'){throw 'CURRENT_UAC_PYTHON_TEST_FAIL'};$neg=Test-EctosQfPythonVersionContract -Version ([Version]'3.9.0');if($neg.Status -ne 'FAIL'){throw 'PYTHON_VERSION_NEGATIVE_CONTROL_FAIL'}}
Add-EctosQfTestResult 'CURRENT_CANONICAL_HANDOFF_CONTRACT_TEST' {$result=Test-EctosQfCurrentHandoffContract -PackageRoot $PackageRoot;if($result.Status -ne 'PASS'){throw 'CURRENT_HANDOFF_CONTRACT_FAIL'}}
Add-EctosQfTestResult 'SELF_QUALIFICATION_PROHIBITED_TEST' {$contract=Get-Content -LiteralPath (Join-Path $PackageRoot '01_PROJECT_FREEZE\ECTOS_QF_UAC_ADMISSION_IO_CONTRACT_V02.json') -Raw|ConvertFrom-Json;if($contract.producer_can_self_qualify -ne $false -or $contract.qf_can_self_admit -ne $false){throw 'AUTHORITY_SEPARATION_FAIL'}}
Add-EctosQfTestResult 'CANONICAL_HANDOFF_AUTHORITY_EXTERNAL_TEST' {$contract=Get-Content -LiteralPath (Join-Path $PackageRoot '07_REPORTS\ECTOS_QF_CHANGE_RELEASE_OUTPUT_CONTRACT_V02.json') -Raw|ConvertFrom-Json;if($contract.canonical_handoff_authority_external -ne $true){throw 'HANDOFF_AUTHORITY_NOT_EXTERNAL'}}

$Csv=Join-Path $Root 'SELFTEST_RESULTS.csv'
$Results | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $Csv
$pass=@($Results | Where-Object { $_.STATUS -eq 'PASS' }).Count
$fail=@($Results | Where-Object { $_.STATUS -eq 'FAIL' }).Count
$Summary=[ordered]@{
 OFFICIAL_PROJECT_NAME='ECTOS';PROJECT_NAME='ECTOS DEV - QUALIFICATION FACTORY';PROJECT_ID='ECTOS-DEV-QF-01';SUCCESSOR_VERSION='V05';RUN_ID=$RunId;RUN_ID_DESIGN='SHA256(VERSION|EXACT_PACKAGE_SHA256)';EXACT_PACKAGE_SHA256=$normalizedPackageSha256;NATIVE_PS51_STATUS=$Native.Status;
 SELF_TEST_REQUIRED_COUNT=$Results.Count;SELF_TEST_PASS_COUNT=$pass;SELF_TEST_FAIL_COUNT=$fail;CANDIDATE_BEHAVIORAL_EXECUTION_COUNT=0;PROTECTED_ECTOS_STATE_MUTATION_COUNT=0;RELEASE_PROMOTION_COUNT=0;OS_DEPLOYMENT_COUNT=0;POWERSHELL_SESSION_REMAINS_OPEN='YES'
}
$Summary | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $Root 'SELFTEST_SUMMARY.json') -Encoding UTF8
$Summary.GetEnumerator() | ForEach-Object { Write-Output ($_.Key+'='+$_.Value) }
Write-Output 'POWERSHELL_SESSION_REMAINS_OPEN=YES'
