# ECTOS DEV — Qualification Factory — Execution Boundary

This package implements the Phase 0/1 Qualification Factory baseline defined by the supplied Main Authority prompt.

## Absolute boundary

- No ECTOS Candidate behavioral execution.
- No R02-REQ-016 Gate A or Gate B execution.
- No P5B execution.
- No DEV fast-forward.
- No API02A test execution.
- No ECTOS OS deployment.
- No release promotion.
- No protected Repository/RIM/CTR/ID Bank mutation.
- No self-activation of Main Authority.
- No silent retry after authority consumption.

The self-test suite uses only synthetic or inert fixtures.

## Environment caveat

The package was assembled and archive-validated in a Linux build sandbox where native Windows PowerShell 5.1 is unavailable. Therefore native PS5.1 execution evidence is intentionally marked **NOT_PROVEN_IN_BUILD_SANDBOX**. The included Windows operator must be executed in native `powershell.exe` 5.1 to close that proof. No PASS is inferred from source generation alone.
