Set-StrictMode -Version 2.0
function New-EctosQfOneRunLedger {
 [CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact='Medium')]
 param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][string]$AuthorityId)
 $directoryPath=Split-Path -Parent $Path
 if($directoryPath -and -not (Test-Path -LiteralPath $directoryPath)){
   if($PSCmdlet.ShouldProcess($directoryPath,'Create authority ledger directory')){New-Item -ItemType Directory -Path $directoryPath -Force | Out-Null}
 }
 if(-not $PSCmdlet.ShouldProcess($Path,'Create one-run authority ledger')){return [pscustomobject]@{Status='NOT_CREATED';Path=$Path;AuthorityId=$AuthorityId}}
 $bytes=[Text.Encoding]::UTF8.GetBytes(("AUTHORITY_ID={0}`r`nCONSUMED=YES`r`n" -f $AuthorityId))
 $fileStream=$null
 try{$fileStream=[System.IO.File]::Open($Path,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::Write,[System.IO.FileShare]::None);$fileStream.Write($bytes,0,$bytes.Length)}
 finally{if($null -ne $fileStream){$fileStream.Dispose()}}
 [pscustomobject]@{Status='CREATED';Path=$Path;AuthorityId=$AuthorityId}
}
