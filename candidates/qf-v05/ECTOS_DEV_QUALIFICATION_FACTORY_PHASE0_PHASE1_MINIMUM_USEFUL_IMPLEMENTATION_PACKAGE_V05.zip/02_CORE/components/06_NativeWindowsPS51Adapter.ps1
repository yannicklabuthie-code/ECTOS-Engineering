Set-StrictMode -Version 2.0
function Assert-EctosQfNativeWindowsPowerShell51 {
 [CmdletBinding()] param()
 $edition='Desktop'
 if($PSVersionTable.ContainsKey('PSEdition')){$edition=$PSVersionTable.PSEdition}
 $platform=[Environment]::OSVersion.Platform
 $ok=($platform -eq [PlatformID]::Win32NT -and $PSVersionTable.PSVersion.Major -eq 5 -and $PSVersionTable.PSVersion.Minor -eq 1 -and $edition -eq 'Desktop')
 if(-not $ok){throw ('QF_NATIVE_PS51_REQUIRED ActualVersion={0} Edition={1} Platform={2} EnvOS={3}' -f $PSVersionTable.PSVersion,$edition,$platform,$env:OS)}
 [pscustomobject]@{Status='PASS';Version=$PSVersionTable.PSVersion.ToString();Edition=$edition;Platform=$platform.ToString();EnvOS=$env:OS;ProcessPath=(Get-Process -Id $PID).Path}
}
function Test-EctosQfNativeParse {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][string[]]$Paths)
 $rows=@()
 foreach($pathValue in $Paths){
   $tokens=$null;$parseErrors=$null
   [void][System.Management.Automation.Language.Parser]::ParseFile($pathValue,[ref]$tokens,[ref]$parseErrors)
   $rows += [pscustomobject]@{Path=$pathValue;ParseErrorCount=@($parseErrors).Count;Errors=(@($parseErrors | ForEach-Object { $_.Message }) -join ' || ')}
 }
 $bad=@($rows | Where-Object { $_.ParseErrorCount -gt 0 })
 $sum=0; foreach($row in $rows){$sum += [int]$row.ParseErrorCount}
 [pscustomobject]@{Status=$(if($bad.Count -eq 0){'PASS'}else{'FAIL'});ParseErrorCount=$sum;Rows=$rows}
}
