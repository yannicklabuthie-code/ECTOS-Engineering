# Qualification Factory Self-Test Contract

The 25 mandatory tests use only generated temporary files, synthetic ZIPs and inert child processes. They do not import, execute, mutate, or bind to any real ECTOS Candidate, ECTOS OS, Repository protected state, RIM, CTR or ID Bank.

The runner requires native Windows PowerShell 5.1 Desktop and fails closed on any other runtime. It does not call `exit`, does not retry failed tests automatically, and does not create or consume Main Authority.
