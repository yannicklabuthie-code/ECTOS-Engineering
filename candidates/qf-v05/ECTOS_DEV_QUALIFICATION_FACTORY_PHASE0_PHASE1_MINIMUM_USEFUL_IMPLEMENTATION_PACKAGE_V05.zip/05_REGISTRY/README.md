# Registry initialization

The master register contains only package identities directly supported by the supplied Main Authority prompt. The lot register uses the mandated initial architecture buckets and deliberately leaves unknown membership unassigned. No historical lot is relabeled QF-qualified.
