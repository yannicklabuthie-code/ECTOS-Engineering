Set-StrictMode -Version 2.0
function Get-EctosQfRunId {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$Seed)
 $sha=[System.Security.Cryptography.SHA256]::Create()
 try{$bytes=[Text.Encoding]::UTF8.GetBytes($Seed);$hash=$sha.ComputeHash($bytes);$hex=([BitConverter]::ToString($hash)).Replace('-','');return ('QF_'+$hex.Substring(0,20))}
 finally{$sha.Dispose()}
}
function Write-EctosQfRegistryRow {
 [CmdletBinding(SupportsShouldProcess=$true,ConfirmImpact='Low')]
 param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][psobject]$Row)
 $directoryPath=Split-Path -Parent $Path
 if($directoryPath -and -not(Test-Path -LiteralPath $directoryPath)){if($PSCmdlet.ShouldProcess($directoryPath,'Create registry directory')){New-Item -ItemType Directory -Path $directoryPath -Force | Out-Null}}
 if(-not $PSCmdlet.ShouldProcess($Path,'Write qualification registry row')){return}
 if(Test-Path -LiteralPath $Path){@($Row)|Export-Csv -LiteralPath $Path -NoTypeInformation -Append -Encoding UTF8}else{@($Row)|Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8}
}
function Invoke-EctosQfSelfTestCase {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$Name,[Parameter(Mandatory=$true)][scriptblock]$Body)
 try{& $Body;[pscustomobject]@{TEST=$Name;STATUS='PASS';DETAIL=''}}catch{[pscustomobject]@{TEST=$Name;STATUS='FAIL';DETAIL=$_.Exception.Message}}
}
