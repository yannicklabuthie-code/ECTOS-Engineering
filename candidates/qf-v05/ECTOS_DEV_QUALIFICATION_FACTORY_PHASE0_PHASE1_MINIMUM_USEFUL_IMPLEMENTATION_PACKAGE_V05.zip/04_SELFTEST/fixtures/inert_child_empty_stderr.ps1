[Console]::Out.Write('INERT_STDOUT')
