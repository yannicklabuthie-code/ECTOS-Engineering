# ECTOS QF Phase 0 Architecture Freeze V01

## Identity

- Official project: ECTOS
- Project: ECTOS DEV — QUALIFICATION FACTORY
- Project ID: ECTOS-DEV-QF-01
- Parent architecture: ECTOS_DEV_ARCHITECTURE_ENVIRONNEMENT_DEVELOPPEMENT_QUALIFICATION_CHANGE_RELEASE_V0.2
- Factory position: internal component of ECTOS DEV
- Separate ECTOS plane: NO
- Release authority: NO
- Self-authorization: NO
- Release promotion: NO
- OS deployment: NO

## Canonical workspace

Canonical qualification root is `C:\EQ\`. Downloads, AppData and TEMP are non-canonical human I/O or transient boundaries only. Workspace, registry and repository remain separate concepts.

Required directories: `00_INTAKE`, `01_STAGE`, `02_STATIC`, `03_NATIVE`, `04_HARNESS`, `05_BEHAVIORAL`, `06_PROTECTED_STATE`, `07_EVIDENCE`, `08_AUTHORITY`, `09_RELEASE`, `CORE`, `PROFILES`, `SELFTEST`, `LOGS`, `REGISTRY`.

## Architecture pattern

The factory uses a modular common core with thin profiled operators. A monolithic runner is prohibited. The common core exposes 13 minimum logical components: workspace management; package intake/byte identity; ZIP/manifest validation; SHA-256 validation; static analysis; native Windows PS5.1 adapter; harness qualification; authority-template validation; one-run authority ledger; protected-state observer contract; evidence builder; failure attribution; self-test runner/registry interface (implemented as separate registered components in the component register).

## Standard pipeline

- Q0 — Intake and exact-byte identity
- Q1 — Package / ZIP / manifest / closure
- Q2 — Source static analysis
- Q3 — Native runtime qualification
- Q4 — Harness and qualification-infrastructure qualification
- Q5 — Explicit-authority behavioral execution
- Q6 — Evidence review and failure attribution
- Q7 — Main Authority acceptance and release decision

Q0-Q4 do not execute Candidate behavior. Q5 requires explicit active Main Authority. Q6 does not re-execute Candidate behavior. Q7 has no automatic promotion.

## Frozen separation rules

- QUALIFICATION_FACTORY_INSIDE_ECTOS_DEV=YES
- DEV_REPOSITORY_OWNS_QF_ARTIFACTS=YES
- QF_SEPARATE_PHYSICAL_REPOSITORY_REQUIRED_NOW=NO
- QF_ASSETS_USE_DEV_REPOSITORY_LOGICAL_NAMESPACE=YES
- WORKSPACE_NOT_EQUAL_REPOSITORY=YES
- REGISTRY_NOT_EQUAL_REPOSITORY=YES
- BUILD_NOT_EQUAL_QUALIFICATION=YES
- QUALIFICATION_NOT_EQUAL_AUTHORITY=YES
- HISTORICAL_ACCEPTANCE_NOT_EQUAL_QF_QUALIFICATION=YES
- CORRECTION_NOT_EQUAL_PROMOTION=YES
- NO_SILENT_RETRY=YES
- NO_SILENT_PATCH=YES
- QF_MUST_SELF_QUALIFY=YES

## Phase 0 exit rule

Architecture is considered frozen only when all contracts and registers required by Phase 0 exist and are internally consistent. This build supplies those artifacts.
