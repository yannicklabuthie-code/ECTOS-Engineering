[Console]::Out.Write('INERT_OK')
