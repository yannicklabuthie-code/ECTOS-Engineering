Set-StrictMode -Version 2.0

function Test-EctosQfAssignedAutomaticVariable {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][System.Management.Automation.Language.Ast]$Ast)
    $reserved=@('PID','PSEdition','PSVersionTable','PSScriptRoot','PSCommandPath','MyInvocation','Host','HOME','Error','Args','Input','Matches','PSItem','_','This','StackTrace','NestedPromptLevel','LASTEXITCODE','ExecutionContext')
    $reservedMap=@{}
    foreach($reservedName in $reserved){$reservedMap[$reservedName.ToLowerInvariant()]=$true}
    $hits=@()
    $assignments=@($Ast.FindAll({param($node) $node -is [System.Management.Automation.Language.AssignmentStatementAst]},$true))
    foreach($assignment in $assignments){
        if($assignment.Left -is [System.Management.Automation.Language.VariableExpressionAst]){
            $name=$assignment.Left.VariablePath.UserPath
            if($reservedMap.ContainsKey($name.ToLowerInvariant())){$hits += $name}
        }
    }
    $parameters=@($Ast.FindAll({param($node) $node -is [System.Management.Automation.Language.ParameterAst]},$true))
    foreach($parameter in $parameters){
        $name=$parameter.Name.VariablePath.UserPath
        if($reservedMap.ContainsKey($name.ToLowerInvariant())){$hits += $name}
    }
    return @($hits | Sort-Object -Unique)
}

function Invoke-EctosQfStaticAnalysis {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Path)
    $tokens=$null
    $errors=$null
    $ast=[System.Management.Automation.Language.Parser]::ParseFile($Path,[ref]$tokens,[ref]$errors)
    $text=[System.IO.File]::ReadAllText($Path)
    $ruleHits=@()
    if($text -match '\$[A-Za-z_][A-Za-z0-9_]*:'){ $ruleHits += 'PS51-R001' }
    if($text -match '(?m)=\s*if\s*\('){ $ruleHits += 'PS51-R002' }
    $unsafeDefaultCount=0
    $parameterNodes=@($ast.FindAll({param($node) $node -is [System.Management.Automation.Language.ParameterAst]},$true))
    foreach($parameterNode in $parameterNodes){
        if($null -ne $parameterNode.DefaultValue){
            $defaultVariables=@($parameterNode.DefaultValue.FindAll({param($node) $node -is [System.Management.Automation.Language.VariableExpressionAst]},$true))
            if(@($defaultVariables | Where-Object { $_.VariablePath.UserPath -eq 'PSScriptRoot' }).Count -gt 0){$unsafeDefaultCount++}
        }
    }
    if($unsafeDefaultCount -gt 0){ $ruleHits += 'PS51-R003' }
    if($text -match '(?i)Get-ChildItem[^\r\n]*-ErrorAction\s+SilentlyContinue'){ $ruleHits += 'PS51-R004' }
    if($text -match 'SCAN_SCOPE=REPOSITORY_ROOT'){ $ruleHits += 'PS51-R005' }
    $reservedHits=@(Test-EctosQfAssignedAutomaticVariable -Ast $ast)
    if($reservedHits.Count -gt 0){ $ruleHits += 'PS51-R006' }
    $functions=@($ast.FindAll({param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst]},$true))
    $singleLetterHelpers=@($functions | Where-Object { $_.Name.Length -eq 1 } | ForEach-Object { $_.Name })
    $uniqueRuleHits=@($ruleHits | Sort-Object -Unique)
    $status='PASS'
    if(@($errors).Count -gt 0 -or $uniqueRuleHits.Count -gt 0 -or $singleLetterHelpers.Count -gt 0){$status='FAIL'}
    [pscustomobject]@{
        ParseErrorCount=@($errors).Count
        ActiveRuleHitCount=$uniqueRuleHits.Count
        ActiveRuleHits=$uniqueRuleHits
        AutomaticReservedVariableCollisionCount=$reservedHits.Count
        AutomaticReservedVariableCollisions=$reservedHits
        SingleLetterHelperCount=$singleLetterHelpers.Count
        SingleLetterHelpers=$singleLetterHelpers
        MalformedTokenCount=@($errors).Count
        Status=$status
        ParseErrors=@($errors | ForEach-Object { $_.Message })
    }
}
