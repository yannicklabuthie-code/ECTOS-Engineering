# ECTOS DEV Repository Logical Namespace V01

Logical model only; no repository migration is performed by this package.

- 00_CONTROL
- 01_SOURCES
- 02_COMPONENTS
- 03_BUILDS
- 04_PACKAGES
- 05_QF_PROFILES
- 06_TESTS_FIXTURES
- 07_QUALIFICATION_EVIDENCE
- 08_RELEASE_CANDIDATES
- 09_REGISTERS
- 10_DEV_LEARNING
- 11_ARCHIVE

QF artifacts remain owned by ECTOS DEV. A separate QF repository is not required now. Workspace and registry remain distinct from the repository.
