Set-StrictMode -Version 2.0
function Test-EctosQfSha256 {
 [CmdletBinding()] param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][ValidatePattern('^[A-Fa-f0-9]{64}$')][string]$ExpectedSha256)
 $actual=(Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToUpperInvariant()
 [pscustomobject]@{ Status=if($actual -eq $ExpectedSha256.ToUpperInvariant()){'PASS'}else{'FAIL'}; Expected=$ExpectedSha256.ToUpperInvariant(); Actual=$actual }
}
